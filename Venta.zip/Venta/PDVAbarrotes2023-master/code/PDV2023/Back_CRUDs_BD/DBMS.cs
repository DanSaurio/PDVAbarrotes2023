﻿using System;
namespace Back_CRUDs_BD
{
	public enum DBMS
	{
		MYSQL,
		MARIABD,
		SQLSERVER,
		MONGODB,
		ORACLE,
		POSTGRESQL,
		INFORMIX
	}
}

