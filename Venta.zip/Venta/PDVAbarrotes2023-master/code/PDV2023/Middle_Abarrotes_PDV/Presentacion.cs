﻿using System;
namespace Middle_Abarrotes_PDV
{
	public enum Presentacion
	{
		PIEZA,
		KILO,
		CAJA,
		LITRO
	}
}

